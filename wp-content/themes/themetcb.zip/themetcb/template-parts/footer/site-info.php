<?php
/**
 * Displays footer info
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?>
<div class="info">
<?php
            echo'<div class="view-content">';
            echo'<div class="views-row baners_home">';
            echo'<div class="views-field">';
            echo'<div class="field-content center">';
            the_custom_footer_banner();
            echo'</div>';
            echo'</div>';
            echo'</div>';
            echo'</div>';

?>
    <h2>Connecting Business and Security</h2>
</div><!-- .info -->
