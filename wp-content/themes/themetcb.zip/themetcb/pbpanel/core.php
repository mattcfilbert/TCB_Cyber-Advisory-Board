<?php
    /*====================================*\
        FUNCTIONS
    \*====================================*/

    function pbpanel_options($option) {
        $option('pbpanel_notebook_1',  '');
        $option('pbpanel_notebook_2',  '');
        $option('pbpanel_notebook_3',  '');
        $option('pbpanel_exclusive_1', '');
        $option('pbpanel_exclusive_2', '');
        $option('pbpanel_exclusive_3', '');
        $option('pbpanel_exclusive_4', '');
        $option('pbpanel_exclusive_5', '');
        $option('pbpanel_exclusive_6', '');
    }